---
id: OFF-mRPPrVXX
nummer: OFF-2025-003
kundeId: KD-SJWly-zv
kontaktId: [object Object]
titel: "WordPress Website mit Shop 33"
datum: 2025-10-02
gültigBis: 2025-12-01
status: entwurf
zahlungsbedingungen: "30 Tage netto"
mwstSatz: 7.7
erstellt: 2025-10-02T13:54:20.173Z
---

# Offerte OFF-2025-003

**Titel:** WordPress Website mit Shop 33  
**Datum:** 2025-10-02  
**Gültig bis:** 2025-12-01  
**Status:** entwurf

## Beschreibung



## Zahlungsbedingungen

30 Tage netto

## Notizen


