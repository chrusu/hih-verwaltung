---
id: KD-SJWly-zv
nummer: KUNDE-002
name: "Max Mustermann test"
email: "max@mustermann.ch"
telefon: "012 345 67 89"
typ: privat
adresse:
  strasse: "Testgasse 42"
  plz: "3000"
  ort: "Bern"
  land: "Schweiz"
erstellt: 2025-10-02T13:21:29.219Z
aktiv: true
---

# Max Mustermann test

**Kundennummer:** KUNDE-002  
**Typ:** privat

## Kontakt

**Email:** max@mustermann.ch  
**Telefon:** 012 345 67 89

## Adresse

Testgasse 42  
3000 Bern  
Schweiz

## Notizen


